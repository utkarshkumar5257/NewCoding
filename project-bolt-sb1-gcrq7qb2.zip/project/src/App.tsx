import React, { useState, useRef, useEffect } from 'react';
import { Send, Smile, AlertCircle } from 'lucide-react';

type Message = {
  text: string;
  sender: 'user' | 'assistant';
  timestamp: Date;
};

function App() {
  const [messages, setMessages] = useState<Message[]>([
    {
      text: "Hello! I'm here to listen and support you. How are you feeling today?",
      sender: 'assistant',
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState('');
  const [mood, setMood] = useState<number>(5);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      text: input,
      sender: 'user',
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');

    // Simulate AI response
    setTimeout(() => {
      const response: Message = {
        text: getTherapyResponse(input),
        sender: 'assistant',
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, response]);
    }, 1000);
  };

  const getTherapyResponse = (input: string): string => {
    const responses = [
      "I understand how you're feeling. Could you tell me more about that?",
      "That sounds challenging. How long have you been feeling this way?",
      "You're not alone in this. What helps you cope when you feel this way?",
      "I hear you. Would you like to explore some coping strategies together?",
      "Thank you for sharing that with me. How can I best support you right now?",
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <header className="bg-white shadow-sm py-4 px-6">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <h1 className="text-2xl font-semibold text-gray-800">Virtual Therapy Assistant</h1>
          <div className="flex items-center gap-2">
            <AlertCircle className="text-red-500" />
            <span className="text-sm text-gray-600">
              In crisis? Call 988 for immediate help
            </span>
          </div>
        </div>
      </header>

      <div className="flex-1 max-w-4xl w-full mx-auto p-6 flex gap-6">
        {/* Main Chat Area */}
        <div className="flex-1 bg-white rounded-lg shadow-md flex flex-col">
          {/* Messages */}
          <div className="flex-1 p-4 overflow-y-auto">
            {messages.map((message, index) => (
              <div
                key={index}
                className={`mb-4 flex ${
                  message.sender === 'user' ? 'justify-end' : 'justify-start'
                }`}
              >
                <div
                  className={`max-w-[80%] rounded-lg p-3 ${
                    message.sender === 'user'
                      ? 'bg-blue-500 text-white'
                      : 'bg-gray-100 text-gray-800'
                  }`}
                >
                  <p>{message.text}</p>
                  <p className="text-xs mt-1 opacity-70">
                    {message.timestamp.toLocaleTimeString()}
                  </p>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div className="border-t p-4">
            <div className="flex gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Type your message..."
                className="flex-1 rounded-lg border border-gray-300 px-4 py-2 focus:outline-none focus:border-blue-500"
              />
              <button
                onClick={handleSend}
                className="bg-blue-500 text-white rounded-lg px-4 py-2 hover:bg-blue-600 transition-colors"
              >
                <Send size={20} />
              </button>
            </div>
          </div>
        </div>

        {/* Mood Tracker */}
        <div className="w-64 bg-white rounded-lg shadow-md p-4">
          <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Smile className="text-yellow-500" />
            Mood Tracker
          </h2>
          <div className="space-y-4">
            <input
              type="range"
              min="1"
              max="10"
              value={mood}
              onChange={(e) => setMood(Number(e.target.value))}
              className="w-full"
            />
            <div className="flex justify-between text-sm text-gray-600">
              <span>😢</span>
              <span>😐</span>
              <span>😊</span>
            </div>
            <p className="text-center text-gray-700 mt-2">
              Current Mood: {mood}/10
            </p>
          </div>
        </div>
      </div>

      {/* Disclaimer */}
      <footer className="bg-gray-100 py-3 px-6 text-center text-sm text-gray-600">
        This is not a replacement for professional medical advice. If you're experiencing a mental health emergency, please call 988 or contact a mental health professional.
      </footer>
    </div>
  );
}

export default App;